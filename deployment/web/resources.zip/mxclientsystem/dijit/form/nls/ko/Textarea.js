//>>built
define("dijit/form/nls/ko/Textarea",({iframeEditTitle:"편집 영역",iframeFocusTitle:"편집 영역 프레임"}));
